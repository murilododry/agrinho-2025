let fruta;
let obstaculos = [];
let pontos = 0;
let velocidade = 3;

function setup() {
  createCanvas(400, 600);
  fruta = new Fruta();
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Desenha e movimenta a fruta
  fruta.mostrar();
  fruta.mover();

  // Cria obstáculos aleatórios
  if (frameCount % 60 === 0) {
    obstaculos.push(new Obstaculo());
  }

  // Desenha e movimenta obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].mostrar();
    obstaculos[i].mover();

    // Verifica colisão
    if (obstaculos[i].colidir(fruta)) {
      pontos -= 10; // Perde pontos
      obstaculos.splice(i, 1); // Remove o obstáculo
    } else if (obstaculos[i].saiuDaTela()) {
      obstaculos.splice(i, 1);
      pontos += 5; // Ganha pontos
    }
  }

  // Mostra pontuação
  fill(0);
  textSize(24);
  text(`Pontos: ${pontos}`, 20, 30);
}

// Classe da fruta (morango)
class Fruta {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.tamanho = 30;
  }

  mostrar() {
    fill(255, 0, 0); // Vermelho (morango)
    ellipse(this.x, this.y, this.tamanho);
    fill(0, 128, 0); // Verde (caule)
    rect(this.x - 5, this.y - 20, 10, 15);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width) {
      this.x += 5;
    }
  }
}

// Classe dos obstáculos
class Obstaculo {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.largura = random(30, 70);
    this.altura = random(20, 40);
    this.cor = color(random(100, 200), random(100, 200), random(100, 200));
  }

  mostrar() {
    fill(this.cor);
    rect(this.x, this.y, this.largura, this.altura);
  }

  mover() {
    this.y += velocidade;
  }

  colidir(fruta) {
    return (
      fruta.x + fruta.tamanho / 2 > this.x &&
      fruta.x - fruta.tamanho / 2 < this.x + this.largura &&
      fruta.y + fruta.tamanho / 2 > this.y &&
      fruta.y - fruta.tamanho / 2 < this.y + this.altura
    );
  }

  saiuDaTela() {
    return this.y > height;
  }
}
